﻿namespace Dev
{
    partial class PrimaryCaseWindow
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions customHeaderButtonImageOptions1 = new DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PrimaryCaseWindow));
            DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions customHeaderButtonImageOptions2 = new DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions customHeaderButtonImageOptions3 = new DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions customHeaderButtonImageOptions4 = new DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject4 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions customHeaderButtonImageOptions5 = new DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject5 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions customHeaderButtonImageOptions6 = new DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject6 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions customHeaderButtonImageOptions7 = new DevExpress.XtraBars.Docking.CustomHeaderButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject7 = new DevExpress.Utils.SerializableAppearanceObject();
            this.documentManager1 = new DevExpress.XtraBars.Docking2010.DocumentManager(this.components);
            this.widgetView1 = new DevExpress.XtraBars.Docking2010.Views.Widget.WidgetView(this.components);
            this.columnDefinition1 = new DevExpress.XtraBars.Docking2010.Views.Widget.ColumnDefinition();
            this.columnDefinition2 = new DevExpress.XtraBars.Docking2010.Views.Widget.ColumnDefinition();
            this.columnDefinition3 = new DevExpress.XtraBars.Docking2010.Views.Widget.ColumnDefinition();
            this.columnDefinition4 = new DevExpress.XtraBars.Docking2010.Views.Widget.ColumnDefinition();
            this.document1 = new DevExpress.XtraBars.Docking2010.Views.Widget.Document(this.components);
            this.document2 = new DevExpress.XtraBars.Docking2010.Views.Widget.Document(this.components);
            this.document3 = new DevExpress.XtraBars.Docking2010.Views.Widget.Document(this.components);
            this.document4 = new DevExpress.XtraBars.Docking2010.Views.Widget.Document(this.components);
            this.document5 = new DevExpress.XtraBars.Docking2010.Views.Widget.Document(this.components);
            this.document6 = new DevExpress.XtraBars.Docking2010.Views.Widget.Document(this.components);
            this.document9 = new DevExpress.XtraBars.Docking2010.Views.Widget.Document(this.components);
            this.document10 = new DevExpress.XtraBars.Docking2010.Views.Widget.Document(this.components);
            this.document7 = new DevExpress.XtraBars.Docking2010.Views.Widget.Document(this.components);
            this.rowDefinition1 = new DevExpress.XtraBars.Docking2010.Views.Widget.RowDefinition();
            this.rowDefinition2 = new DevExpress.XtraBars.Docking2010.Views.Widget.RowDefinition();
            this.rowDefinition3 = new DevExpress.XtraBars.Docking2010.Views.Widget.RowDefinition();
            this.rowDefinition4 = new DevExpress.XtraBars.Docking2010.Views.Widget.RowDefinition();
            this.rowDefinition5 = new DevExpress.XtraBars.Docking2010.Views.Widget.RowDefinition();
            this.rowDefinition6 = new DevExpress.XtraBars.Docking2010.Views.Widget.RowDefinition();
            ((System.ComponentModel.ISupportInitialize)(this.documentManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.widgetView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.columnDefinition1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.columnDefinition2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.columnDefinition3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.columnDefinition4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.document1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.document2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.document3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.document4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.document5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.document6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.document9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.document10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.document7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rowDefinition1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rowDefinition2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rowDefinition3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rowDefinition4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rowDefinition5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rowDefinition6)).BeginInit();
            this.SuspendLayout();
            // 
            // documentManager1
            // 
            this.documentManager1.ContainerControl = this;
            this.documentManager1.View = this.widgetView1;
            this.documentManager1.ViewCollection.AddRange(new DevExpress.XtraBars.Docking2010.Views.BaseView[] {
            this.widgetView1});
            // 
            // widgetView1
            // 
            this.widgetView1.Columns.AddRange(new DevExpress.XtraBars.Docking2010.Views.Widget.ColumnDefinition[] {
            this.columnDefinition1,
            this.columnDefinition2,
            this.columnDefinition3,
            this.columnDefinition4});
            this.widgetView1.Documents.AddRange(new DevExpress.XtraBars.Docking2010.Views.BaseDocument[] {
            this.document1,
            this.document2,
            this.document3,
            this.document4,
            this.document5,
            this.document6,
            this.document9,
            this.document10,
            this.document7});
            this.widgetView1.DocumentSpacing = 5;
            this.widgetView1.LayoutMode = DevExpress.XtraBars.Docking2010.Views.Widget.LayoutMode.TableLayout;
            this.widgetView1.RootContainer.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.widgetView1.Rows.AddRange(new DevExpress.XtraBars.Docking2010.Views.Widget.RowDefinition[] {
            this.rowDefinition1,
            this.rowDefinition2,
            this.rowDefinition3,
            this.rowDefinition4,
            this.rowDefinition5,
            this.rowDefinition6});
            this.widgetView1.QueryControl += new DevExpress.XtraBars.Docking2010.Views.QueryControlEventHandler(this.widgetView1_QueryControl);
            // 
            // document1
            // 
            this.document1.AppearanceCaption.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(168)))));
            this.document1.AppearanceCaption.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(168)))));
            this.document1.AppearanceCaption.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(168)))));
            this.document1.AppearanceCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.document1.AppearanceCaption.Options.UseBackColor = true;
            this.document1.AppearanceCaption.Options.UseBorderColor = true;
            this.document1.AppearanceCaption.Options.UseFont = true;
            this.document1.Caption = "History";
            this.document1.ColumnSpan = 2;
            this.document1.ControlName = "document1";
            this.document1.ControlTypeName = "HistoryView";
            customHeaderButtonImageOptions1.Image = global::Dev.Properties.Resources.icon_16_Expand;
            this.document1.CustomHeaderButtons.AddRange(new DevExpress.XtraBars.Docking2010.IButton[] {
            new DevExpress.XtraBars.Docking.CustomHeaderButton("Button", false, customHeaderButtonImageOptions1, DevExpress.XtraBars.Docking2010.ButtonStyle.PushButton, "Details", -1, true, null, true, false, true, serializableAppearanceObject1, null, -1)});
            this.document1.Height = 291;
            this.document1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("document1.ImageOptions.Image")));
            this.document1.Properties.AllowClose = DevExpress.Utils.DefaultBoolean.False;
            this.document1.Properties.AllowMaximize = DevExpress.Utils.DefaultBoolean.False;
            this.document1.Properties.AllowResize = DevExpress.Utils.DefaultBoolean.False;
            this.document1.Properties.ShowCloseButton = DevExpress.Utils.DefaultBoolean.False;
            this.document1.Properties.ShowMaximizeButton = DevExpress.Utils.DefaultBoolean.False;
            this.document1.RowSpan = 4;
            this.document1.Width = 376;
            // 
            // document2
            // 
            this.document2.AppearanceCaption.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(218)))), ((int)(((byte)(249)))));
            this.document2.AppearanceCaption.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(218)))), ((int)(((byte)(249)))));
            this.document2.AppearanceCaption.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(218)))), ((int)(((byte)(249)))));
            this.document2.AppearanceCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.document2.AppearanceCaption.Options.UseBackColor = true;
            this.document2.AppearanceCaption.Options.UseBorderColor = true;
            this.document2.AppearanceCaption.Options.UseFont = true;
            this.document2.Caption = "General";
            this.document2.ColumnIndex = 2;
            this.document2.ColumnSpan = 2;
            this.document2.ControlName = "document2";
            this.document2.ControlTypeName = "GeneralWidgetView";
            customHeaderButtonImageOptions2.Image = global::Dev.Properties.Resources.icon_16_Expand;
            this.document2.CustomHeaderButtons.AddRange(new DevExpress.XtraBars.Docking2010.IButton[] {
            new DevExpress.XtraBars.Docking.CustomHeaderButton("Button", false, customHeaderButtonImageOptions2, DevExpress.XtraBars.Docking2010.ButtonStyle.PushButton, "Details", -1, true, null, true, false, true, serializableAppearanceObject2, null, -1)});
            this.document2.Height = 111;
            this.document2.ImageOptions.Image = global::Dev.Properties.Resources.icon_head_general;
            this.document2.Properties.AllowClose = DevExpress.Utils.DefaultBoolean.False;
            this.document2.Properties.AllowFloat = DevExpress.Utils.DefaultBoolean.False;
            this.document2.Properties.AllowMaximize = DevExpress.Utils.DefaultBoolean.False;
            this.document2.Properties.AllowResize = DevExpress.Utils.DefaultBoolean.False;
            this.document2.Properties.ShowCloseButton = DevExpress.Utils.DefaultBoolean.False;
            this.document2.Properties.ShowMaximizeButton = DevExpress.Utils.DefaultBoolean.False;
            this.document2.RowSpan = 2;
            this.document2.Width = 377;
            this.document2.CustomButtonClick += new DevExpress.XtraBars.Docking2010.ButtonEventHandler(this.document2_CustomButtonClick);
            // 
            // document3
            // 
            this.document3.AppearanceCaption.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(209)))), ((int)(((byte)(82)))));
            this.document3.AppearanceCaption.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(209)))), ((int)(((byte)(82)))));
            this.document3.AppearanceCaption.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(209)))), ((int)(((byte)(82)))));
            this.document3.AppearanceCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.document3.AppearanceCaption.Options.UseBackColor = true;
            this.document3.AppearanceCaption.Options.UseBorderColor = true;
            this.document3.AppearanceCaption.Options.UseFont = true;
            this.document3.Caption = "Patient";
            this.document3.ColumnIndex = 2;
            this.document3.ControlName = "document3";
            customHeaderButtonImageOptions3.Image = global::Dev.Properties.Resources.icon_16_Expand;
            this.document3.CustomHeaderButtons.AddRange(new DevExpress.XtraBars.Docking2010.IButton[] {
            new DevExpress.XtraBars.Docking.CustomHeaderButton("Button", false, customHeaderButtonImageOptions3, DevExpress.XtraBars.Docking2010.ButtonStyle.PushButton, "Details", -1, true, null, true, false, true, serializableAppearanceObject3, null, -1)});
            this.document3.Height = 125;
            this.document3.ImageOptions.Image = global::Dev.Properties.Resources.icon_head_patient;
            this.document3.Properties.AllowClose = DevExpress.Utils.DefaultBoolean.False;
            this.document3.Properties.AllowFloat = DevExpress.Utils.DefaultBoolean.False;
            this.document3.Properties.AllowMaximize = DevExpress.Utils.DefaultBoolean.False;
            this.document3.Properties.AllowResize = DevExpress.Utils.DefaultBoolean.False;
            this.document3.Properties.ShowCloseButton = DevExpress.Utils.DefaultBoolean.False;
            this.document3.Properties.ShowMaximizeButton = DevExpress.Utils.DefaultBoolean.False;
            this.document3.RowIndex = 2;
            this.document3.RowSpan = 2;
            this.document3.Width = 188;
            // 
            // document4
            // 
            this.document4.AppearanceCaption.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(231)))), ((int)(((byte)(206)))));
            this.document4.AppearanceCaption.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(231)))), ((int)(((byte)(206)))));
            this.document4.AppearanceCaption.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(231)))), ((int)(((byte)(206)))));
            this.document4.AppearanceCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.document4.AppearanceCaption.Options.UseBackColor = true;
            this.document4.AppearanceCaption.Options.UseBorderColor = true;
            this.document4.AppearanceCaption.Options.UseFont = true;
            this.document4.Caption = "Attorney";
            this.document4.ColumnIndex = 3;
            this.document4.ControlName = "document4";
            customHeaderButtonImageOptions4.Image = global::Dev.Properties.Resources.icon_16_Expand;
            this.document4.CustomHeaderButtons.AddRange(new DevExpress.XtraBars.Docking2010.IButton[] {
            new DevExpress.XtraBars.Docking.CustomHeaderButton("Button", false, customHeaderButtonImageOptions4, DevExpress.XtraBars.Docking2010.ButtonStyle.PushButton, "Details", -1, true, null, true, false, true, serializableAppearanceObject4, null, -1)});
            this.document4.Height = 161;
            this.document4.Properties.AllowClose = DevExpress.Utils.DefaultBoolean.False;
            this.document4.Properties.AllowFloat = DevExpress.Utils.DefaultBoolean.False;
            this.document4.Properties.AllowMaximize = DevExpress.Utils.DefaultBoolean.False;
            this.document4.Properties.AllowResize = DevExpress.Utils.DefaultBoolean.False;
            this.document4.Properties.ShowCloseButton = DevExpress.Utils.DefaultBoolean.False;
            this.document4.Properties.ShowMaximizeButton = DevExpress.Utils.DefaultBoolean.False;
            this.document4.RowIndex = 4;
            this.document4.RowSpan = 2;
            this.document4.Width = 189;
            // 
            // document5
            // 
            this.document5.AppearanceCaption.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(227)))), ((int)(((byte)(116)))));
            this.document5.AppearanceCaption.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(227)))), ((int)(((byte)(116)))));
            this.document5.AppearanceCaption.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(227)))), ((int)(((byte)(116)))));
            this.document5.AppearanceCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.document5.AppearanceCaption.Options.UseBackColor = true;
            this.document5.AppearanceCaption.Options.UseBorderColor = true;
            this.document5.AppearanceCaption.Options.UseFont = true;
            this.document5.Caption = "Member\'s Auto Carrier";
            this.document5.ColumnIndex = 3;
            this.document5.ControlName = "document5";
            customHeaderButtonImageOptions5.Image = global::Dev.Properties.Resources.icon_16_Expand;
            this.document5.CustomHeaderButtons.AddRange(new DevExpress.XtraBars.Docking2010.IButton[] {
            new DevExpress.XtraBars.Docking.CustomHeaderButton("Button", false, customHeaderButtonImageOptions5, DevExpress.XtraBars.Docking2010.ButtonStyle.PushButton, "Detail", -1, true, null, true, false, true, serializableAppearanceObject5, null, -1)});
            this.document5.Height = 150;
            this.document5.Properties.AllowClose = DevExpress.Utils.DefaultBoolean.False;
            this.document5.Properties.AllowFloat = DevExpress.Utils.DefaultBoolean.False;
            this.document5.Properties.AllowMaximize = DevExpress.Utils.DefaultBoolean.False;
            this.document5.Properties.AllowResize = DevExpress.Utils.DefaultBoolean.False;
            this.document5.Properties.ShowCloseButton = DevExpress.Utils.DefaultBoolean.False;
            this.document5.Properties.ShowMaximizeButton = DevExpress.Utils.DefaultBoolean.False;
            this.document5.RowIndex = 2;
            this.document5.RowSpan = 2;
            this.document5.Width = 189;
            // 
            // document6
            // 
            this.document6.AppearanceCaption.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(165)))), ((int)(((byte)(232)))));
            this.document6.AppearanceCaption.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(165)))), ((int)(((byte)(232)))));
            this.document6.AppearanceCaption.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(165)))), ((int)(((byte)(232)))));
            this.document6.AppearanceCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.document6.AppearanceCaption.Options.UseBackColor = true;
            this.document6.AppearanceCaption.Options.UseBorderColor = true;
            this.document6.AppearanceCaption.Options.UseFont = true;
            this.document6.Caption = "Injury & Diagnosis";
            this.document6.ColumnIndex = 2;
            this.document6.ControlName = "document6";
            customHeaderButtonImageOptions6.Image = global::Dev.Properties.Resources.icon_16_Expand;
            this.document6.CustomHeaderButtons.AddRange(new DevExpress.XtraBars.Docking2010.IButton[] {
            new DevExpress.XtraBars.Docking.CustomHeaderButton("Button", false, customHeaderButtonImageOptions6, DevExpress.XtraBars.Docking2010.ButtonStyle.PushButton, "Detail", -1, true, null, true, false, true, serializableAppearanceObject6, null, -1)});
            this.document6.Height = 153;
            this.document6.Properties.AllowClose = DevExpress.Utils.DefaultBoolean.False;
            this.document6.Properties.AllowFloat = DevExpress.Utils.DefaultBoolean.False;
            this.document6.Properties.AllowMaximize = DevExpress.Utils.DefaultBoolean.False;
            this.document6.Properties.AllowResize = DevExpress.Utils.DefaultBoolean.False;
            this.document6.Properties.ShowCloseButton = DevExpress.Utils.DefaultBoolean.False;
            this.document6.Properties.ShowMaximizeButton = DevExpress.Utils.DefaultBoolean.False;
            this.document6.RowIndex = 4;
            this.document6.RowSpan = 2;
            this.document6.Width = 188;
            // 
            // document9
            // 
            this.document9.AppearanceCaption.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(186)))), ((int)(((byte)(186)))));
            this.document9.AppearanceCaption.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(186)))), ((int)(((byte)(186)))));
            this.document9.AppearanceCaption.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(186)))), ((int)(((byte)(186)))));
            this.document9.AppearanceCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.document9.AppearanceCaption.Options.UseBackColor = true;
            this.document9.AppearanceCaption.Options.UseBorderColor = true;
            this.document9.AppearanceCaption.Options.UseFont = true;
            this.document9.Caption = "Liability Carrier";
            this.document9.ColumnIndex = 1;
            this.document9.ControlName = "document9";
            customHeaderButtonImageOptions7.Image = global::Dev.Properties.Resources.icon_16_Expand;
            this.document9.CustomHeaderButtons.AddRange(new DevExpress.XtraBars.Docking2010.IButton[] {
            new DevExpress.XtraBars.Docking.CustomHeaderButton("Button", false, customHeaderButtonImageOptions7, DevExpress.XtraBars.Docking2010.ButtonStyle.PushButton, "Detail", -1, true, null, true, false, true, serializableAppearanceObject7, null, -1)});
            this.document9.Height = 138;
            this.document9.Properties.AllowClose = DevExpress.Utils.DefaultBoolean.False;
            this.document9.Properties.AllowFloat = DevExpress.Utils.DefaultBoolean.False;
            this.document9.Properties.AllowMaximize = DevExpress.Utils.DefaultBoolean.False;
            this.document9.Properties.AllowResize = DevExpress.Utils.DefaultBoolean.False;
            this.document9.Properties.ShowCloseButton = DevExpress.Utils.DefaultBoolean.False;
            this.document9.Properties.ShowMaximizeButton = DevExpress.Utils.DefaultBoolean.False;
            this.document9.RowIndex = 4;
            this.document9.RowSpan = 2;
            this.document9.Width = 188;
            // 
            // document10
            // 
            this.document10.AppearanceCaption.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(187)))), ((int)(((byte)(186)))));
            this.document10.AppearanceCaption.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(187)))), ((int)(((byte)(186)))));
            this.document10.AppearanceCaption.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(187)))), ((int)(((byte)(186)))));
            this.document10.AppearanceCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.document10.AppearanceCaption.ForeColor = System.Drawing.Color.White;
            this.document10.AppearanceCaption.Options.UseBackColor = true;
            this.document10.AppearanceCaption.Options.UseBorderColor = true;
            this.document10.AppearanceCaption.Options.UseFont = true;
            this.document10.AppearanceCaption.Options.UseForeColor = true;
            this.document10.Caption = "Scaned Documents";
            this.document10.ControlName = "document10";
            this.document10.ControlTypeName = "Documents";
            this.document10.Properties.AllowClose = DevExpress.Utils.DefaultBoolean.False;
            this.document10.Properties.AllowFloat = DevExpress.Utils.DefaultBoolean.False;
            this.document10.Properties.AllowMaximize = DevExpress.Utils.DefaultBoolean.False;
            this.document10.Properties.AllowResize = DevExpress.Utils.DefaultBoolean.False;
            this.document10.Properties.ShowCloseButton = DevExpress.Utils.DefaultBoolean.False;
            this.document10.Properties.ShowMaximizeButton = DevExpress.Utils.DefaultBoolean.False;
            this.document10.RowIndex = 4;
            // 
            // document7
            // 
            this.document7.AppearanceCaption.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(171)))), ((int)(((byte)(107)))));
            this.document7.AppearanceCaption.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(171)))), ((int)(((byte)(107)))));
            this.document7.AppearanceCaption.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(171)))), ((int)(((byte)(107)))));
            this.document7.AppearanceCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.document7.AppearanceCaption.ForeColor = System.Drawing.Color.White;
            this.document7.AppearanceCaption.Options.UseBackColor = true;
            this.document7.AppearanceCaption.Options.UseBorderColor = true;
            this.document7.AppearanceCaption.Options.UseFont = true;
            this.document7.AppearanceCaption.Options.UseForeColor = true;
            this.document7.Caption = "Saved Documents";
            this.document7.ControlName = "document11";
            this.document7.ControlTypeName = "Documents";
            this.document7.Properties.AllowClose = DevExpress.Utils.DefaultBoolean.False;
            this.document7.Properties.AllowFloat = DevExpress.Utils.DefaultBoolean.False;
            this.document7.Properties.AllowMaximize = DevExpress.Utils.DefaultBoolean.False;
            this.document7.Properties.AllowResize = DevExpress.Utils.DefaultBoolean.False;
            this.document7.Properties.ShowCloseButton = DevExpress.Utils.DefaultBoolean.False;
            this.document7.Properties.ShowMaximizeButton = DevExpress.Utils.DefaultBoolean.False;
            this.document7.RowIndex = 5;
            // 
            // rowDefinition1
            // 
            this.rowDefinition1.Length.UnitType = DevExpress.XtraBars.Docking2010.Views.Widget.LengthUnitType.Pixel;
            this.rowDefinition1.Length.UnitValue = 110D;
            // 
            // rowDefinition2
            // 
            this.rowDefinition2.Length.UnitType = DevExpress.XtraBars.Docking2010.Views.Widget.LengthUnitType.Pixel;
            this.rowDefinition2.Length.UnitValue = 110D;
            // 
            // rowDefinition3
            // 
            this.rowDefinition3.Length.UnitType = DevExpress.XtraBars.Docking2010.Views.Widget.LengthUnitType.Pixel;
            this.rowDefinition3.Length.UnitValue = 110D;
            // 
            // rowDefinition4
            // 
            this.rowDefinition4.Length.UnitType = DevExpress.XtraBars.Docking2010.Views.Widget.LengthUnitType.Pixel;
            this.rowDefinition4.Length.UnitValue = 110D;
            // 
            // rowDefinition5
            // 
            this.rowDefinition5.Length.UnitType = DevExpress.XtraBars.Docking2010.Views.Widget.LengthUnitType.Pixel;
            this.rowDefinition5.Length.UnitValue = 110D;
            // 
            // rowDefinition6
            // 
            this.rowDefinition6.Length.UnitType = DevExpress.XtraBars.Docking2010.Views.Widget.LengthUnitType.Pixel;
            this.rowDefinition6.Length.UnitValue = 110D;
            // 
            // PrimaryCaseWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.DoubleBuffered = true;
            this.Name = "PrimaryCaseWindow";
            this.Size = new System.Drawing.Size(1300, 700);
            ((System.ComponentModel.ISupportInitialize)(this.documentManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.widgetView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.columnDefinition1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.columnDefinition2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.columnDefinition3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.columnDefinition4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.document1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.document2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.document3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.document4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.document5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.document6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.document9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.document10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.document7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rowDefinition1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rowDefinition2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rowDefinition3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rowDefinition4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rowDefinition5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rowDefinition6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraBars.Docking2010.DocumentManager documentManager1;
        private DevExpress.XtraBars.Docking2010.Views.Widget.WidgetView widgetView1;
        private DevExpress.XtraBars.Docking2010.Views.Widget.ColumnDefinition columnDefinition1;
        private DevExpress.XtraBars.Docking2010.Views.Widget.ColumnDefinition columnDefinition2;
        private DevExpress.XtraBars.Docking2010.Views.Widget.ColumnDefinition columnDefinition3;
        private DevExpress.XtraBars.Docking2010.Views.Widget.ColumnDefinition columnDefinition4;
        private DevExpress.XtraBars.Docking2010.Views.Widget.Document document1;
        private DevExpress.XtraBars.Docking2010.Views.Widget.Document document2;
        private DevExpress.XtraBars.Docking2010.Views.Widget.Document document3;
        private DevExpress.XtraBars.Docking2010.Views.Widget.Document document4;
        private DevExpress.XtraBars.Docking2010.Views.Widget.Document document5;
        private DevExpress.XtraBars.Docking2010.Views.Widget.Document document6;
        private DevExpress.XtraBars.Docking2010.Views.Widget.Document document9;
        private DevExpress.XtraBars.Docking2010.Views.Widget.Document document10;
        private DevExpress.XtraBars.Docking2010.Views.Widget.Document document7;
        private DevExpress.XtraBars.Docking2010.Views.Widget.RowDefinition rowDefinition1;
        private DevExpress.XtraBars.Docking2010.Views.Widget.RowDefinition rowDefinition2;
        private DevExpress.XtraBars.Docking2010.Views.Widget.RowDefinition rowDefinition3;
        private DevExpress.XtraBars.Docking2010.Views.Widget.RowDefinition rowDefinition4;
        private DevExpress.XtraBars.Docking2010.Views.Widget.RowDefinition rowDefinition5;
        private DevExpress.XtraBars.Docking2010.Views.Widget.RowDefinition rowDefinition6;
    }
}
