﻿namespace Dev.PCW.Patient
{
    partial class PatientWigetView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.Root = new DevExpress.XtraLayout.LayoutControlGroup();
            this.simpleLabelItem1 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem2 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem3 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem4 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem5 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem6 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem7 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem8 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem9 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleSeparator1 = new DevExpress.XtraLayout.SimpleSeparator();
            this.simpleLabelItem10 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem11 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem12 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem13 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem14 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem15 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem16 = new DevExpress.XtraLayout.SimpleLabelItem();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem16)).BeginInit();
            this.SuspendLayout();
            // 
            // layoutControl1
            // 
            this.layoutControl1.BackColor = System.Drawing.Color.Transparent;
            this.layoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl1.Location = new System.Drawing.Point(0, 0);
            this.layoutControl1.Margin = new System.Windows.Forms.Padding(0);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.Root = this.Root;
            this.layoutControl1.Size = new System.Drawing.Size(354, 200);
            this.layoutControl1.TabIndex = 0;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // Root
            // 
            this.Root.BackgroundImageOptions.Image = global::Dev.Properties.Resources.icon_bg_patient;
            this.Root.BackgroundImageOptions.Layout = System.Windows.Forms.ImageLayout.Center;
            this.Root.ContentImageOptions.Image = global::Dev.Properties.Resources.icon_bg_patient;
            this.Root.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.Root.GroupBordersVisible = false;
            this.Root.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.simpleLabelItem1,
            this.simpleLabelItem2,
            this.simpleLabelItem3,
            this.simpleLabelItem4,
            this.simpleLabelItem5,
            this.simpleLabelItem6,
            this.simpleLabelItem7,
            this.simpleLabelItem8,
            this.simpleLabelItem9,
            this.simpleSeparator1,
            this.simpleLabelItem10,
            this.simpleLabelItem11,
            this.simpleLabelItem12,
            this.simpleLabelItem13,
            this.simpleLabelItem14,
            this.simpleLabelItem15,
            this.simpleLabelItem16});
            this.Root.Name = "Root";
            this.Root.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.Root.Size = new System.Drawing.Size(354, 200);
            this.Root.TextVisible = false;
            // 
            // simpleLabelItem1
            // 
            this.simpleLabelItem1.AllowHotTrack = false;
            this.simpleLabelItem1.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem1.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem1.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem1.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem1.Location = new System.Drawing.Point(0, 157);
            this.simpleLabelItem1.Name = "simpleLabelItem1";
            this.simpleLabelItem1.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 0, 4);
            this.simpleLabelItem1.Size = new System.Drawing.Size(175, 39);
            this.simpleLabelItem1.Text = "Arizona, Phenoix";
            this.simpleLabelItem1.TextSize = new System.Drawing.Size(114, 17);
            // 
            // simpleLabelItem2
            // 
            this.simpleLabelItem2.AllowHotTrack = false;
            this.simpleLabelItem2.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem2.AppearanceItemCaption.ForeColor = System.Drawing.Color.Black;
            this.simpleLabelItem2.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem2.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem2.Location = new System.Drawing.Point(0, 0);
            this.simpleLabelItem2.Name = "simpleLabelItem2";
            this.simpleLabelItem2.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem2.Size = new System.Drawing.Size(175, 19);
            this.simpleLabelItem2.Text = "Name";
            this.simpleLabelItem2.TextSize = new System.Drawing.Size(114, 15);
            // 
            // simpleLabelItem3
            // 
            this.simpleLabelItem3.AllowHotTrack = false;
            this.simpleLabelItem3.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem3.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem3.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem3.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem3.Location = new System.Drawing.Point(0, 19);
            this.simpleLabelItem3.Name = "simpleLabelItem3";
            this.simpleLabelItem3.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 2, 4);
            this.simpleLabelItem3.Size = new System.Drawing.Size(175, 23);
            this.simpleLabelItem3.Text = "MR. John Smith";
            this.simpleLabelItem3.TextSize = new System.Drawing.Size(114, 17);
            // 
            // simpleLabelItem4
            // 
            this.simpleLabelItem4.AllowHotTrack = false;
            this.simpleLabelItem4.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem4.AppearanceItemCaption.ForeColor = System.Drawing.Color.Black;
            this.simpleLabelItem4.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem4.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem4.Location = new System.Drawing.Point(0, 42);
            this.simpleLabelItem4.Name = "simpleLabelItem4";
            this.simpleLabelItem4.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 8, 0);
            this.simpleLabelItem4.Size = new System.Drawing.Size(175, 23);
            this.simpleLabelItem4.Text = "Member ID";
            this.simpleLabelItem4.TextSize = new System.Drawing.Size(114, 15);
            // 
            // simpleLabelItem5
            // 
            this.simpleLabelItem5.AllowHotTrack = false;
            this.simpleLabelItem5.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem5.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem5.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem5.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem5.Location = new System.Drawing.Point(0, 65);
            this.simpleLabelItem5.Name = "simpleLabelItem5";
            this.simpleLabelItem5.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 2, 4);
            this.simpleLabelItem5.Size = new System.Drawing.Size(175, 23);
            this.simpleLabelItem5.Text = "PATID12345";
            this.simpleLabelItem5.TextSize = new System.Drawing.Size(114, 17);
            // 
            // simpleLabelItem6
            // 
            this.simpleLabelItem6.AllowHotTrack = false;
            this.simpleLabelItem6.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem6.AppearanceItemCaption.ForeColor = System.Drawing.Color.Black;
            this.simpleLabelItem6.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem6.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem6.Location = new System.Drawing.Point(0, 88);
            this.simpleLabelItem6.Name = "simpleLabelItem6";
            this.simpleLabelItem6.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 8, 0);
            this.simpleLabelItem6.Size = new System.Drawing.Size(175, 23);
            this.simpleLabelItem6.Text = "Address";
            this.simpleLabelItem6.TextSize = new System.Drawing.Size(114, 15);
            // 
            // simpleLabelItem7
            // 
            this.simpleLabelItem7.AllowHotTrack = false;
            this.simpleLabelItem7.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem7.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem7.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem7.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem7.Location = new System.Drawing.Point(0, 111);
            this.simpleLabelItem7.Name = "simpleLabelItem7";
            this.simpleLabelItem7.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 2, 4);
            this.simpleLabelItem7.Size = new System.Drawing.Size(175, 23);
            this.simpleLabelItem7.Text = "123, Loreum Ipsum";
            this.simpleLabelItem7.TextSize = new System.Drawing.Size(114, 17);
            // 
            // simpleLabelItem8
            // 
            this.simpleLabelItem8.AllowHotTrack = false;
            this.simpleLabelItem8.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem8.AppearanceItemCaption.ForeColor = System.Drawing.Color.Black;
            this.simpleLabelItem8.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem8.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem8.Location = new System.Drawing.Point(0, 134);
            this.simpleLabelItem8.Name = "simpleLabelItem8";
            this.simpleLabelItem8.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 8, 0);
            this.simpleLabelItem8.Size = new System.Drawing.Size(175, 23);
            this.simpleLabelItem8.Text = "State/City";
            this.simpleLabelItem8.TextSize = new System.Drawing.Size(114, 15);
            // 
            // simpleLabelItem9
            // 
            this.simpleLabelItem9.AllowHotTrack = false;
            this.simpleLabelItem9.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem9.AppearanceItemCaption.ForeColor = System.Drawing.Color.Black;
            this.simpleLabelItem9.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem9.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem9.Location = new System.Drawing.Point(176, 0);
            this.simpleLabelItem9.Name = "simpleLabelItem9";
            this.simpleLabelItem9.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem9.Size = new System.Drawing.Size(174, 19);
            this.simpleLabelItem9.Text = "Name";
            this.simpleLabelItem9.TextSize = new System.Drawing.Size(114, 15);
            // 
            // simpleSeparator1
            // 
            this.simpleSeparator1.AllowHotTrack = false;
            this.simpleSeparator1.Location = new System.Drawing.Point(175, 0);
            this.simpleSeparator1.Name = "simpleSeparator1";
            this.simpleSeparator1.Size = new System.Drawing.Size(1, 196);
            // 
            // simpleLabelItem10
            // 
            this.simpleLabelItem10.AllowHotTrack = false;
            this.simpleLabelItem10.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem10.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem10.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem10.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem10.Location = new System.Drawing.Point(176, 19);
            this.simpleLabelItem10.Name = "simpleLabelItem10";
            this.simpleLabelItem10.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 2, 4);
            this.simpleLabelItem10.Size = new System.Drawing.Size(174, 23);
            this.simpleLabelItem10.Text = "MR. John Smith";
            this.simpleLabelItem10.TextSize = new System.Drawing.Size(114, 17);
            // 
            // simpleLabelItem11
            // 
            this.simpleLabelItem11.AllowHotTrack = false;
            this.simpleLabelItem11.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem11.AppearanceItemCaption.ForeColor = System.Drawing.Color.Black;
            this.simpleLabelItem11.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem11.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem11.Location = new System.Drawing.Point(176, 42);
            this.simpleLabelItem11.Name = "simpleLabelItem11";
            this.simpleLabelItem11.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 8, 0);
            this.simpleLabelItem11.Size = new System.Drawing.Size(174, 23);
            this.simpleLabelItem11.Text = "Member ID";
            this.simpleLabelItem11.TextSize = new System.Drawing.Size(114, 15);
            // 
            // simpleLabelItem12
            // 
            this.simpleLabelItem12.AllowHotTrack = false;
            this.simpleLabelItem12.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem12.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem12.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem12.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem12.Location = new System.Drawing.Point(176, 65);
            this.simpleLabelItem12.Name = "simpleLabelItem12";
            this.simpleLabelItem12.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 2, 4);
            this.simpleLabelItem12.Size = new System.Drawing.Size(174, 23);
            this.simpleLabelItem12.Text = "PATID12345";
            this.simpleLabelItem12.TextSize = new System.Drawing.Size(114, 17);
            // 
            // simpleLabelItem13
            // 
            this.simpleLabelItem13.AllowHotTrack = false;
            this.simpleLabelItem13.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem13.AppearanceItemCaption.ForeColor = System.Drawing.Color.Black;
            this.simpleLabelItem13.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem13.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem13.Location = new System.Drawing.Point(176, 88);
            this.simpleLabelItem13.Name = "simpleLabelItem13";
            this.simpleLabelItem13.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 8, 0);
            this.simpleLabelItem13.Size = new System.Drawing.Size(174, 23);
            this.simpleLabelItem13.Text = "Address";
            this.simpleLabelItem13.TextSize = new System.Drawing.Size(114, 15);
            // 
            // simpleLabelItem14
            // 
            this.simpleLabelItem14.AllowHotTrack = false;
            this.simpleLabelItem14.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem14.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem14.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem14.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem14.Location = new System.Drawing.Point(176, 111);
            this.simpleLabelItem14.Name = "simpleLabelItem14";
            this.simpleLabelItem14.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 2, 4);
            this.simpleLabelItem14.Size = new System.Drawing.Size(174, 23);
            this.simpleLabelItem14.Text = "123, Loreum Ipsum";
            this.simpleLabelItem14.TextSize = new System.Drawing.Size(114, 17);
            // 
            // simpleLabelItem15
            // 
            this.simpleLabelItem15.AllowHotTrack = false;
            this.simpleLabelItem15.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem15.AppearanceItemCaption.ForeColor = System.Drawing.Color.Black;
            this.simpleLabelItem15.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem15.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem15.Location = new System.Drawing.Point(176, 134);
            this.simpleLabelItem15.Name = "simpleLabelItem15";
            this.simpleLabelItem15.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 8, 0);
            this.simpleLabelItem15.Size = new System.Drawing.Size(174, 23);
            this.simpleLabelItem15.Text = "State/City";
            this.simpleLabelItem15.TextSize = new System.Drawing.Size(114, 15);
            // 
            // simpleLabelItem16
            // 
            this.simpleLabelItem16.AllowHotTrack = false;
            this.simpleLabelItem16.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem16.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem16.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem16.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem16.Location = new System.Drawing.Point(176, 157);
            this.simpleLabelItem16.Name = "simpleLabelItem16";
            this.simpleLabelItem16.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 0, 4);
            this.simpleLabelItem16.Size = new System.Drawing.Size(174, 39);
            this.simpleLabelItem16.Text = "Arizona, Phenoix";
            this.simpleLabelItem16.TextSize = new System.Drawing.Size(114, 17);
            // 
            // PatientWigetView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.layoutControl1);
            this.Name = "PatientWigetView";
            this.Size = new System.Drawing.Size(354, 200);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem16)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup Root;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem1;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem2;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem3;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem4;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem5;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem6;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem7;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem8;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem9;
        private DevExpress.XtraLayout.SimpleSeparator simpleSeparator1;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem10;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem11;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem12;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem13;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem14;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem15;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem16;
    }
}
