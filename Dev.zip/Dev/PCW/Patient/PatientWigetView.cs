﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dev.PCW.Patient
{
    public partial class PatientWigetView : UserControl
    {
        public PatientWigetView()
        {
            InitializeComponent();

            layoutControl1.BestFit();
        }
    }
}
