﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Dev.PCW.General
{
    public partial class General : DevExpress.XtraEditors.XtraForm
    {
        public General()
        {
            InitializeComponent();
        }
    }
}