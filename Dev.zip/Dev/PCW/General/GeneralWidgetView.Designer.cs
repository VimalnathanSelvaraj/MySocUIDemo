﻿namespace Dev.PCW.General
{
    partial class GeneralWidgetView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.Root = new DevExpress.XtraLayout.LayoutControlGroup();
            this.simpleLabelItem1 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem3 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem2 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem4 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem5 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem6 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem19 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem20 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem21 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem22 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem23 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem24 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem7 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem13 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem8 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem14 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem9 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem15 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem16 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem17 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem18 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem10 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem11 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem12 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleSeparator1 = new DevExpress.XtraLayout.SimpleSeparator();
            this.simpleSeparator2 = new DevExpress.XtraLayout.SimpleSeparator();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator2)).BeginInit();
            this.SuspendLayout();
            // 
            // layoutControl1
            // 
            this.layoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl1.Location = new System.Drawing.Point(0, 0);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.Root = this.Root;
            this.layoutControl1.Size = new System.Drawing.Size(578, 201);
            this.layoutControl1.TabIndex = 0;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // Root
            // 
            this.Root.ContentImageOptions.Image = global::Dev.Properties.Resources.icon_bg_general;
            this.Root.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.Root.GroupBordersVisible = false;
            this.Root.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.simpleLabelItem1,
            this.simpleLabelItem3,
            this.simpleLabelItem2,
            this.simpleLabelItem4,
            this.simpleLabelItem5,
            this.simpleLabelItem6,
            this.simpleLabelItem19,
            this.simpleLabelItem20,
            this.simpleLabelItem21,
            this.simpleLabelItem22,
            this.simpleLabelItem23,
            this.simpleLabelItem24,
            this.simpleLabelItem7,
            this.simpleLabelItem13,
            this.simpleLabelItem8,
            this.simpleLabelItem14,
            this.simpleLabelItem9,
            this.simpleLabelItem15,
            this.simpleLabelItem16,
            this.simpleLabelItem17,
            this.simpleLabelItem18,
            this.simpleLabelItem10,
            this.simpleLabelItem11,
            this.simpleLabelItem12,
            this.simpleSeparator1,
            this.simpleSeparator2});
            this.Root.Name = "Root";
            this.Root.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.Root.Size = new System.Drawing.Size(578, 201);
            this.Root.TextVisible = false;
            // 
            // simpleLabelItem1
            // 
            this.simpleLabelItem1.AllowHotTrack = false;
            this.simpleLabelItem1.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem1.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem1.Location = new System.Drawing.Point(0, 0);
            this.simpleLabelItem1.MinSize = new System.Drawing.Size(113, 19);
            this.simpleLabelItem1.Name = "simpleLabelItem1";
            this.simpleLabelItem1.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem1.Size = new System.Drawing.Size(183, 21);
            this.simpleLabelItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem1.Text = "Case Owner";
            this.simpleLabelItem1.TextSize = new System.Drawing.Size(105, 15);
            // 
            // simpleLabelItem3
            // 
            this.simpleLabelItem3.AllowHotTrack = false;
            this.simpleLabelItem3.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem3.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem3.Location = new System.Drawing.Point(0, 47);
            this.simpleLabelItem3.MinSize = new System.Drawing.Size(113, 19);
            this.simpleLabelItem3.Name = "simpleLabelItem3";
            this.simpleLabelItem3.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem3.Size = new System.Drawing.Size(183, 21);
            this.simpleLabelItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem3.Text = "Balance Amount";
            this.simpleLabelItem3.TextSize = new System.Drawing.Size(105, 15);
            // 
            // simpleLabelItem2
            // 
            this.simpleLabelItem2.AllowHotTrack = false;
            this.simpleLabelItem2.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem2.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem2.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem2.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem2.Location = new System.Drawing.Point(0, 21);
            this.simpleLabelItem2.MinSize = new System.Drawing.Size(115, 24);
            this.simpleLabelItem2.Name = "simpleLabelItem2";
            this.simpleLabelItem2.Padding = new DevExpress.XtraLayout.Utils.Padding(5, 5, 2, 5);
            this.simpleLabelItem2.Size = new System.Drawing.Size(183, 26);
            this.simpleLabelItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem2.Text = "Smith Willams";
            this.simpleLabelItem2.TextSize = new System.Drawing.Size(105, 17);
            // 
            // simpleLabelItem4
            // 
            this.simpleLabelItem4.AllowHotTrack = false;
            this.simpleLabelItem4.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem4.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem4.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem4.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem4.Location = new System.Drawing.Point(0, 68);
            this.simpleLabelItem4.MinSize = new System.Drawing.Size(113, 25);
            this.simpleLabelItem4.Name = "simpleLabelItem4";
            this.simpleLabelItem4.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 4);
            this.simpleLabelItem4.Size = new System.Drawing.Size(183, 27);
            this.simpleLabelItem4.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem4.Text = "$1052.25";
            this.simpleLabelItem4.TextSize = new System.Drawing.Size(105, 17);
            // 
            // simpleLabelItem5
            // 
            this.simpleLabelItem5.AllowHotTrack = false;
            this.simpleLabelItem5.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem5.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem5.Location = new System.Drawing.Point(0, 95);
            this.simpleLabelItem5.MinSize = new System.Drawing.Size(113, 19);
            this.simpleLabelItem5.Name = "simpleLabelItem5";
            this.simpleLabelItem5.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem5.Size = new System.Drawing.Size(183, 21);
            this.simpleLabelItem5.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem5.Text = "Statue of Limitation";
            this.simpleLabelItem5.TextSize = new System.Drawing.Size(105, 15);
            // 
            // simpleLabelItem6
            // 
            this.simpleLabelItem6.AllowHotTrack = false;
            this.simpleLabelItem6.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem6.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem6.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem6.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem6.Location = new System.Drawing.Point(0, 116);
            this.simpleLabelItem6.MinSize = new System.Drawing.Size(113, 25);
            this.simpleLabelItem6.Name = "simpleLabelItem6";
            this.simpleLabelItem6.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 4);
            this.simpleLabelItem6.Size = new System.Drawing.Size(183, 27);
            this.simpleLabelItem6.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem6.Text = "Minima";
            this.simpleLabelItem6.TextSize = new System.Drawing.Size(105, 17);
            // 
            // simpleLabelItem19
            // 
            this.simpleLabelItem19.AllowHotTrack = false;
            this.simpleLabelItem19.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem19.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem19.Location = new System.Drawing.Point(0, 143);
            this.simpleLabelItem19.MinSize = new System.Drawing.Size(113, 19);
            this.simpleLabelItem19.Name = "simpleLabelItem19";
            this.simpleLabelItem19.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem19.Size = new System.Drawing.Size(183, 21);
            this.simpleLabelItem19.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem19.Text = "Subscriber ID";
            this.simpleLabelItem19.TextSize = new System.Drawing.Size(105, 15);
            // 
            // simpleLabelItem20
            // 
            this.simpleLabelItem20.AllowHotTrack = false;
            this.simpleLabelItem20.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem20.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem20.Location = new System.Drawing.Point(184, 143);
            this.simpleLabelItem20.MinSize = new System.Drawing.Size(113, 19);
            this.simpleLabelItem20.Name = "simpleLabelItem20";
            this.simpleLabelItem20.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem20.Size = new System.Drawing.Size(201, 21);
            this.simpleLabelItem20.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem20.Text = "Subscriber ID";
            this.simpleLabelItem20.TextSize = new System.Drawing.Size(105, 15);
            // 
            // simpleLabelItem21
            // 
            this.simpleLabelItem21.AllowHotTrack = false;
            this.simpleLabelItem21.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem21.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem21.Location = new System.Drawing.Point(386, 143);
            this.simpleLabelItem21.MinSize = new System.Drawing.Size(113, 19);
            this.simpleLabelItem21.Name = "simpleLabelItem21";
            this.simpleLabelItem21.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem21.Size = new System.Drawing.Size(188, 21);
            this.simpleLabelItem21.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem21.Text = "Subscriber ID";
            this.simpleLabelItem21.TextSize = new System.Drawing.Size(105, 15);
            // 
            // simpleLabelItem22
            // 
            this.simpleLabelItem22.AllowHotTrack = false;
            this.simpleLabelItem22.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem22.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem22.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem22.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem22.Location = new System.Drawing.Point(386, 164);
            this.simpleLabelItem22.MinSize = new System.Drawing.Size(113, 25);
            this.simpleLabelItem22.Name = "simpleLabelItem22";
            this.simpleLabelItem22.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 4);
            this.simpleLabelItem22.Size = new System.Drawing.Size(188, 33);
            this.simpleLabelItem22.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem22.Text = "1663254";
            this.simpleLabelItem22.TextSize = new System.Drawing.Size(105, 17);
            // 
            // simpleLabelItem23
            // 
            this.simpleLabelItem23.AllowHotTrack = false;
            this.simpleLabelItem23.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem23.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem23.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem23.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem23.Location = new System.Drawing.Point(184, 164);
            this.simpleLabelItem23.MinSize = new System.Drawing.Size(113, 25);
            this.simpleLabelItem23.Name = "simpleLabelItem23";
            this.simpleLabelItem23.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 4);
            this.simpleLabelItem23.Size = new System.Drawing.Size(201, 33);
            this.simpleLabelItem23.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem23.Text = "1663254";
            this.simpleLabelItem23.TextSize = new System.Drawing.Size(105, 17);
            // 
            // simpleLabelItem24
            // 
            this.simpleLabelItem24.AllowHotTrack = false;
            this.simpleLabelItem24.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem24.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem24.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem24.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem24.Location = new System.Drawing.Point(0, 164);
            this.simpleLabelItem24.MinSize = new System.Drawing.Size(113, 25);
            this.simpleLabelItem24.Name = "simpleLabelItem24";
            this.simpleLabelItem24.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 4);
            this.simpleLabelItem24.Size = new System.Drawing.Size(183, 33);
            this.simpleLabelItem24.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem24.Text = "1663254";
            this.simpleLabelItem24.TextSize = new System.Drawing.Size(105, 17);
            // 
            // simpleLabelItem7
            // 
            this.simpleLabelItem7.AllowHotTrack = false;
            this.simpleLabelItem7.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem7.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem7.Location = new System.Drawing.Point(184, 0);
            this.simpleLabelItem7.MinSize = new System.Drawing.Size(113, 19);
            this.simpleLabelItem7.Name = "simpleLabelItem7";
            this.simpleLabelItem7.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem7.Size = new System.Drawing.Size(201, 21);
            this.simpleLabelItem7.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem7.Text = "Case Owner";
            this.simpleLabelItem7.TextSize = new System.Drawing.Size(105, 15);
            // 
            // simpleLabelItem13
            // 
            this.simpleLabelItem13.AllowHotTrack = false;
            this.simpleLabelItem13.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem13.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem13.Location = new System.Drawing.Point(386, 0);
            this.simpleLabelItem13.MinSize = new System.Drawing.Size(113, 19);
            this.simpleLabelItem13.Name = "simpleLabelItem13";
            this.simpleLabelItem13.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem13.Size = new System.Drawing.Size(188, 21);
            this.simpleLabelItem13.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem13.Text = "Case Owner";
            this.simpleLabelItem13.TextSize = new System.Drawing.Size(105, 15);
            // 
            // simpleLabelItem8
            // 
            this.simpleLabelItem8.AllowHotTrack = false;
            this.simpleLabelItem8.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem8.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem8.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem8.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem8.Location = new System.Drawing.Point(184, 21);
            this.simpleLabelItem8.MinSize = new System.Drawing.Size(115, 24);
            this.simpleLabelItem8.Name = "simpleLabelItem8";
            this.simpleLabelItem8.Padding = new DevExpress.XtraLayout.Utils.Padding(5, 5, 2, 5);
            this.simpleLabelItem8.Size = new System.Drawing.Size(201, 26);
            this.simpleLabelItem8.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem8.Text = "Smith Willams";
            this.simpleLabelItem8.TextSize = new System.Drawing.Size(105, 17);
            // 
            // simpleLabelItem14
            // 
            this.simpleLabelItem14.AllowHotTrack = false;
            this.simpleLabelItem14.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem14.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem14.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem14.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem14.Location = new System.Drawing.Point(386, 21);
            this.simpleLabelItem14.MinSize = new System.Drawing.Size(115, 24);
            this.simpleLabelItem14.Name = "simpleLabelItem14";
            this.simpleLabelItem14.Padding = new DevExpress.XtraLayout.Utils.Padding(5, 5, 2, 5);
            this.simpleLabelItem14.Size = new System.Drawing.Size(188, 26);
            this.simpleLabelItem14.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem14.Text = "Smith Willams";
            this.simpleLabelItem14.TextSize = new System.Drawing.Size(105, 17);
            // 
            // simpleLabelItem9
            // 
            this.simpleLabelItem9.AllowHotTrack = false;
            this.simpleLabelItem9.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem9.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem9.Location = new System.Drawing.Point(184, 47);
            this.simpleLabelItem9.MinSize = new System.Drawing.Size(113, 19);
            this.simpleLabelItem9.Name = "simpleLabelItem9";
            this.simpleLabelItem9.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem9.Size = new System.Drawing.Size(201, 21);
            this.simpleLabelItem9.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem9.Text = "Balance Amount";
            this.simpleLabelItem9.TextSize = new System.Drawing.Size(105, 15);
            // 
            // simpleLabelItem15
            // 
            this.simpleLabelItem15.AllowHotTrack = false;
            this.simpleLabelItem15.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem15.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem15.Location = new System.Drawing.Point(386, 47);
            this.simpleLabelItem15.MinSize = new System.Drawing.Size(113, 19);
            this.simpleLabelItem15.Name = "simpleLabelItem15";
            this.simpleLabelItem15.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem15.Size = new System.Drawing.Size(188, 21);
            this.simpleLabelItem15.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem15.Text = "Balance Amount";
            this.simpleLabelItem15.TextSize = new System.Drawing.Size(105, 15);
            // 
            // simpleLabelItem16
            // 
            this.simpleLabelItem16.AllowHotTrack = false;
            this.simpleLabelItem16.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem16.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem16.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem16.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem16.Location = new System.Drawing.Point(386, 68);
            this.simpleLabelItem16.MinSize = new System.Drawing.Size(113, 25);
            this.simpleLabelItem16.Name = "simpleLabelItem16";
            this.simpleLabelItem16.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 4);
            this.simpleLabelItem16.Size = new System.Drawing.Size(188, 27);
            this.simpleLabelItem16.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem16.Text = "$10236.253";
            this.simpleLabelItem16.TextSize = new System.Drawing.Size(105, 17);
            // 
            // simpleLabelItem17
            // 
            this.simpleLabelItem17.AllowHotTrack = false;
            this.simpleLabelItem17.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem17.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem17.Location = new System.Drawing.Point(386, 95);
            this.simpleLabelItem17.MinSize = new System.Drawing.Size(113, 19);
            this.simpleLabelItem17.Name = "simpleLabelItem17";
            this.simpleLabelItem17.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem17.Size = new System.Drawing.Size(188, 21);
            this.simpleLabelItem17.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem17.Text = "Statue of Limitation";
            this.simpleLabelItem17.TextSize = new System.Drawing.Size(105, 15);
            // 
            // simpleLabelItem18
            // 
            this.simpleLabelItem18.AllowHotTrack = false;
            this.simpleLabelItem18.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem18.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem18.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem18.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem18.Location = new System.Drawing.Point(386, 116);
            this.simpleLabelItem18.MinSize = new System.Drawing.Size(113, 25);
            this.simpleLabelItem18.Name = "simpleLabelItem18";
            this.simpleLabelItem18.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 4);
            this.simpleLabelItem18.Size = new System.Drawing.Size(188, 27);
            this.simpleLabelItem18.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem18.Text = "Minima";
            this.simpleLabelItem18.TextSize = new System.Drawing.Size(105, 17);
            // 
            // simpleLabelItem10
            // 
            this.simpleLabelItem10.AllowHotTrack = false;
            this.simpleLabelItem10.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem10.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem10.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem10.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem10.Location = new System.Drawing.Point(184, 68);
            this.simpleLabelItem10.MinSize = new System.Drawing.Size(113, 25);
            this.simpleLabelItem10.Name = "simpleLabelItem10";
            this.simpleLabelItem10.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 4);
            this.simpleLabelItem10.Size = new System.Drawing.Size(201, 27);
            this.simpleLabelItem10.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem10.Text = "$1025.263";
            this.simpleLabelItem10.TextSize = new System.Drawing.Size(105, 17);
            // 
            // simpleLabelItem11
            // 
            this.simpleLabelItem11.AllowHotTrack = false;
            this.simpleLabelItem11.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem11.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem11.Location = new System.Drawing.Point(184, 95);
            this.simpleLabelItem11.MinSize = new System.Drawing.Size(113, 19);
            this.simpleLabelItem11.Name = "simpleLabelItem11";
            this.simpleLabelItem11.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 0);
            this.simpleLabelItem11.Size = new System.Drawing.Size(201, 21);
            this.simpleLabelItem11.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem11.Text = "Statue of Limitation";
            this.simpleLabelItem11.TextSize = new System.Drawing.Size(105, 15);
            // 
            // simpleLabelItem12
            // 
            this.simpleLabelItem12.AllowHotTrack = false;
            this.simpleLabelItem12.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleLabelItem12.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(46)))), ((int)(((byte)(93)))));
            this.simpleLabelItem12.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem12.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem12.Location = new System.Drawing.Point(184, 116);
            this.simpleLabelItem12.MinSize = new System.Drawing.Size(113, 25);
            this.simpleLabelItem12.Name = "simpleLabelItem12";
            this.simpleLabelItem12.Padding = new DevExpress.XtraLayout.Utils.Padding(4, 4, 4, 4);
            this.simpleLabelItem12.Size = new System.Drawing.Size(201, 27);
            this.simpleLabelItem12.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem12.Text = "Minima";
            this.simpleLabelItem12.TextSize = new System.Drawing.Size(105, 17);
            // 
            // simpleSeparator1
            // 
            this.simpleSeparator1.AllowHotTrack = false;
            this.simpleSeparator1.Location = new System.Drawing.Point(183, 0);
            this.simpleSeparator1.Name = "simpleSeparator1";
            this.simpleSeparator1.Size = new System.Drawing.Size(1, 197);
            // 
            // simpleSeparator2
            // 
            this.simpleSeparator2.AllowHotTrack = false;
            this.simpleSeparator2.Location = new System.Drawing.Point(385, 0);
            this.simpleSeparator2.Name = "simpleSeparator2";
            this.simpleSeparator2.Size = new System.Drawing.Size(1, 197);
            // 
            // GeneralWidgetView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.layoutControl1);
            this.Name = "GeneralWidgetView";
            this.Size = new System.Drawing.Size(578, 201);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup Root;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem1;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem3;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem2;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem4;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem5;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem6;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem7;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem8;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem9;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem10;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem11;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem12;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem13;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem14;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem15;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem16;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem17;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem18;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem19;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem20;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem21;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem22;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem23;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem24;
        private DevExpress.XtraLayout.SimpleSeparator simpleSeparator1;
        private DevExpress.XtraLayout.SimpleSeparator simpleSeparator2;
    }
}
