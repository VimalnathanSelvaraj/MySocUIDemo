﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dev.UserComponents;

namespace Dev
{
    public partial class SearchCritetiaSelector : UserControl
    {
        public SearchCritetiaSelector()
        {
            InitializeComponent();
        }

        private void SearchCritetiaSelector_Load(object sender, EventArgs e)
        {
            List<string> searchList = new List<string>()
            {
                "Case ID",
                "Case Type",
                "Member First Name",
                "Member Last Name",
                "Diary Date",
                "Case Unit",
                "Case Owner",
                "Case Type",
                "Plan Type"
            };

            foreach (var item in searchList)
            {
                flpSearchList.Controls.Add(new SearchListItem() { SearchItemName = item });
            }


            List<string> searchSelectedList = new List<string>()
            {
                "Case ID",
                "Case Type",
                "Member First Name",
                "Member Last Name",
                "Diary Date"
            };

            foreach (var item in searchSelectedList)
            {
                flpSelectedSearchList.Controls.Add(new SearchListItem() { SearchItemName = item });
            }
        }

        private void flpSelectedSearchList_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void flpSelectedSearchList_DragDrop(object sender, DragEventArgs e)
        {
            SearchListItem data = e.Data.GetData(typeof(SearchListItem)) as SearchListItem;
            FlowLayoutPanel _destination = sender as FlowLayoutPanel;

            Point p = _destination.PointToClient(new Point(e.X, e.Y));
            var item = _destination.GetChildAtPoint(p);
            int index = _destination.Controls.GetChildIndex(item, false);
            _destination.Controls.SetChildIndex(data, index);
            _destination.Invalidate();
        }
    }
}
