﻿using Dev.PCW.General;
using DevExpress.XtraEditors;
using DevExpress.XtraLayout;
using DevExpress.XtraLayout.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dev
{
    public partial class Form1 : XtraForm
    {
        General genral = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void widgetView1_QueryControl(object sender, DevExpress.XtraBars.Docking2010.Views.QueryControlEventArgs e)
        {
            e.Control = new Label() { Text = "Hello" };
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            flyoutPanel1.HideBeakForm();

            layoutControl1.BeginUpdate();
            // Create a layout item within the group. 
            LayoutControlItem item1 = Root.AddItem();
            item1.TextVisible = false;
            // Bind a control to the layout item. 
            TextEdit CustomtextEdit1 = new TextEdit();
            CustomtextEdit1.Name = "TextEdit1";
            CustomtextEdit1.Properties.NullValuePrompt = "Custom edit";
            CustomtextEdit1.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(246)))), ((int)(((byte)(250))))); ;
            CustomtextEdit1.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(191)))));
            CustomtextEdit1.Properties.Appearance.Options.UseBackColor = true;
            CustomtextEdit1.Properties.Appearance.Options.UseForeColor = true;
            CustomtextEdit1.Properties.AppearanceFocused.ForeColor = System.Drawing.Color.Black;
            CustomtextEdit1.Properties.AppearanceFocused.Options.UseForeColor = true;
            CustomtextEdit1.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            CustomtextEdit1.Properties.Padding = new System.Windows.Forms.Padding(3);
            CustomtextEdit1.EditValueChanged += textEdit2_EditValueChanged;
            item1.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            item1.Control = CustomtextEdit1;

            // Create a layout item that will display a date editor. 
            DateEdit dtEdit1 = new DateEdit();
            dtEdit1.Name = "dtEdit1";
            dtEdit1.Properties.NullValuePrompt = "Diary Date";
            dtEdit1.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(246)))), ((int)(((byte)(250)))));
            CustomtextEdit1.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(191)))));
            dtEdit1.Properties.Appearance.Options.UseBackColor = true;
            dtEdit1.Properties.Appearance.Options.UseForeColor = true;
            dtEdit1.Properties.AppearanceFocused.ForeColor = System.Drawing.Color.Black;
            dtEdit1.Properties.AppearanceFocused.Options.UseForeColor = true;
            dtEdit1.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            dtEdit1.Properties.Padding = new System.Windows.Forms.Padding(3); LayoutControlItem item2 = new LayoutControlItem(layoutControl1, dtEdit1);
            // Position this item to the right of item1 
            item2.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            item2.Move(item1, InsertType.Right);
            item2.TextVisible = false;
            // Add the created group to the root group. 
            layoutControl1.BestFit();
            layoutControl1.EndUpdate();


            this.primaryCaseWindow1.OnCustomButtonClicked += PrimaryCaseWindow1_OnCustomButtonClicked;

        }

        private void PrimaryCaseWindow1_OnCustomButtonClicked(object sender, EventArgs e)
        {
            if (genral == null)
            {
                genral = new General() { ShowInTaskbar = false };
                genral.Parent = this;
                genral.Show();
                genral.BringToFront();
            }
            else
            {
                genral.MdiParent = this;
                genral.Show();
                genral.BringToFront();
                genral.Focus();
            }
        }

        private void textEdit2_EditValueChanged(object sender, EventArgs e)
        {
            string value = (sender as TextEdit).EditValue.ToString();

            (sender as TextEdit).ForeColor = String.IsNullOrWhiteSpace(value) ? Color.Gray : Color.FromArgb(82, 82, 82);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            flyoutPanelControl1.Controls.Add(new SearchCritetiaSelector());
            flyoutPanel1.ShowBeakForm();

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
