﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dev.PCW.General;

namespace Dev
{
    public partial class PrimaryCaseWindow : UserControl
    {

        public event EventHandler OnCustomButtonClicked;

        public PrimaryCaseWindow()
        {
            InitializeComponent();
        }

        private void widgetView1_QueryControl(object sender, DevExpress.XtraBars.Docking2010.Views.QueryControlEventArgs e)
        {
            if (e.Document.ControlTypeName == "HistoryView")
            {
                e.Control = new PCW.History.HistoryView() { Dock = DockStyle.Fill };
            }
            else if (e.Document.ControlTypeName == "GeneralWidgetView")
            {
                e.Control = new PCW.General.GeneralWidgetView() { Dock = DockStyle.Fill };
            }
            else if (e.Document.ControlTypeName == "Documents")
            {
                e.Control = new Control() { BackColor = Color.White };
            }
            else
            {
                e.Control = new PCW.Patient.PatientWigetView() { Dock = DockStyle.Fill };
            }
        }

        private void document1_CustomButtonClick(object sender, DevExpress.XtraBars.Docking2010.ButtonEventArgs e)
        {

        }

        private void document2_CustomButtonClick(object sender, DevExpress.XtraBars.Docking2010.ButtonEventArgs e)
        {
            OnCustomButtonClicked?.Invoke(sender, e);
        }
    }
}
